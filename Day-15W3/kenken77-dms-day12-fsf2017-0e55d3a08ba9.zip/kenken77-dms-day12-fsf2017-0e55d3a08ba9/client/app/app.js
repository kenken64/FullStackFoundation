(function (){
    angular
        .module("DMS", 
         ["ngMessages", "ngAnimate"]);
})();