<?php
    include_once "config.php";
     include_once "jsfunctions.php";

    $page       =   "invite_body.php";
    include_once "template.php";

?>
