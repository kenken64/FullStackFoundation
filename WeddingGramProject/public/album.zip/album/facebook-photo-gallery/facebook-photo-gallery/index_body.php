<div id="divbody">
    <div style="margin-top: 20px;">
        <div class="bodyleft1">
            <div class="bodystep">
                <div class="step">
                    Step 1:
                </div>
                <div>
                    <span>
                        <fb:login-button size="large" length="long" onlogin='fbcloggedin();'></fb:login-button>
                    </span>
                    <br />
                    <div style="margin-left: 70px; color: red; font-size: 12px; font-weight: bold;">
                        (click the button above)
                    </div>
                </div>
                <br />
            </div>
        </div>
        <div class="bodyleft2">
            <img src="<?=$config['base_url']?>/public/images/home_left.jpg" alt="home left" />
        </div>
        <div class="clear"></div>
        <br /><br />
    </div>
</div>