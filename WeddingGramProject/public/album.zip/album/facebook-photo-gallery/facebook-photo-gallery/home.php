<?php
    include_once "config.php";
    include_once "fbobject.php";
    include_once "jsfunctions.php";
    
    $page       =   "home_body.php";
    include_once "template.php";

?>